package com.example.zopa;

/**
 * Created by m.karandish on 6/8/2019.
 */
public interface PositiveCategoryTest {
}
